# 🌦️ wheather-prediction1

This project predicts weather conditions such as temperature using historical weather data and machine learning models.

## 📁 Folder Overview
- `Video Demo/` - (Optional) Include a demo video of the project.
- `docx/` - (Optional) Reports or documentation.
- `project files/` - Contains source code, model, and dataset.

## 🧠 Technologies
- Python
- Pandas, NumPy
- Scikit-learn
- Joblib

## 🚀 How to Use

1. Train the model:
```bash
python src/train_model.py
```

2. Run predictions:
```bash
python src/predict.py
```

## 📌 Author
Renukadevi18
