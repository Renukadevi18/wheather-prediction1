import joblib
import numpy as np

model = joblib.load('../model/weather_model.pkl')
sample = np.array([[70, 2.0, 10]])
prediction = model.predict(sample)

print(f"Predicted Temperature: {prediction[0]:.2f}°C")
